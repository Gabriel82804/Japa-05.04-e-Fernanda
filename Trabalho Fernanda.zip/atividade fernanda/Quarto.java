import javax.swing.JOptionPane;


public class Quarto {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Quar s1 =  new Quar();
		s1.r =  Double .parseDouble(JOptionPane .showInputDialog("Digite a quantidade de reais: "));
		s1.d = Double .parseDouble(JOptionPane .showInputDialog("Digite quanto do dolar: "));
		
		System.out.println("Quantidade de dolar: " + (s1.r/s1.d));
	}

}
