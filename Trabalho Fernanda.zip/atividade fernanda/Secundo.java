import javax.swing.JOptionPane;


public class Secundo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Sec s1 = new Sec();
		s1.n1 = Integer .parseInt(JOptionPane .showInputDialog("Digite o primeiro numero "));
		s1.n2 = Integer .parseInt(JOptionPane .showInputDialog("Digite o segundo numero "));
		s1.n3 = Integer .parseInt(JOptionPane .showInputDialog("Digite o terceiro numero "));
		
		System.out.println("Resposta Soma: " + (s1.n1 + s1.n2 + s1.n3) * (s1.n1 + s1.n2 + s1.n3));
	}
}
