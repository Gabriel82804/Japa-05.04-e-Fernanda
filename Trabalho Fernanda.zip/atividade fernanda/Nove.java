import javax.swing.JOptionPane;

public class Nove {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Nov n = new Nov();
		n.sal = Double.parseDouble(JOptionPane.showInputDialog("Salario: "));
		n.desp = Double.parseDouble(JOptionPane.showInputDialog("Despezas: "));
		
		System.out.print("Tempo para ser milionario: " + 1000000/(n.sal-n.desp)*12 +"Anos para se tornar milionario!!");
	}

}
