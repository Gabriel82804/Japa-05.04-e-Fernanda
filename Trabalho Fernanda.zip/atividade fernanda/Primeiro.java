import javax.swing.JOptionPane;


public class Primeiro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Pri p1 = new Pri();
		p1.numero = Double.parseDouble(JOptionPane.showInputDialog("Digite um numero para gerar o quadrado do mesmo: "));
		
		System.out.println("Resultado �: " + p1.numero * p1.numero);
		}
	}


