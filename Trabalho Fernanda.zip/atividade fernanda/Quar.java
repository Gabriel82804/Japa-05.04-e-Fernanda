
public class Quar {

	double r;
	double d;
	double resp;
	
	public double getR() {
		return r;
	}
	public void setR(double r) {
		this.r = r;
	}
	public double getD() {
		return d;
	}
	public void setD(double d) {
		this.d = d;
	}
	public double getResp() {
		return resp;
	}
	public void setResp(double resp) {
		this.resp = resp;
	}
	
	
}
