import javax.swing.JOptionPane;

public class Setimo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Set s = new Set();
		s.h = Double.parseDouble(JOptionPane.showInputDialog("Digite a altura: "));
		s.r = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor de R: "));
		
		System.out.print("Volume" + 3.14*(s.r*s.r)*s.h);
	}

}
