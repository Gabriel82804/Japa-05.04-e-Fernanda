import javax.swing.JOptionPane;

public class Doze_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Doze d = new Doze();
		d.n1 = Double.parseDouble(JOptionPane.showInputDialog("Digite um numero: "));
		d.n2 = Double.parseDouble(JOptionPane.showInputDialog("Digite um segundo numero: "));
		d.b = JOptionPane.showInputDialog("Digite a opera��o desejada: ");
		
		if(d.b = "+"){
			System.out.println("Resultado: " + (d.n1 + d.n2));
		}
	}

}
