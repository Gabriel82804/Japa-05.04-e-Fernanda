
public class Dez {

	int va;
	int vb;
	int vc;
	int vbr;
	int vn;
	
	public int getVa() {
		return va;
	}
	public void setVa(int va) {
		this.va = va;
	}
	public int getVb() {
		return vb;
	}
	public void setVb(int vb) {
		this.vb = vb;
	}
	public int getVc() {
		return vc;
	}
	public void setVc(int vc) {
		this.vc = vc;
	}
	public int getVbr() {
		return vbr;
	}
	public void setVbr(int vbr) {
		this.vbr = vbr;
	}
	public int getVn() {
		return vn;
	}
	public void setVn(int vn) {
		this.vn = vn;
	}
	
}
