import javax.swing.JOptionPane;

public class sexto {

	public static void main(String[] args) {
		
		Sex s = new Sex();
		s.n1 = Double.parseDouble(JOptionPane.showInputDialog("Graus Celcius: "));
		
		System.out.print("Graus Fahrenheit: " + (9*s.n1 + 160)/5);
		
	}

}
