import javax.swing.JOptionPane;

public class Dez_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Dez d = new Dez();
		d.va = Integer.parseInt(JOptionPane.showInputDialog("Quantidades de votos do candidato A: "));
		d.vb = Integer.parseInt(JOptionPane.showInputDialog("Quantidades de votos do candidato B: "));
		d.vc = Integer.parseInt(JOptionPane.showInputDialog("Quantidades de votos do candidato C: "));
		d.vbr = Integer.parseInt(JOptionPane.showInputDialog("Quantidades de votos 	Brancos: "));
		d.vn = Integer.parseInt(JOptionPane.showInputDialog("Quantidades de votos Nulos: "));
		
		System.out.print("Total de eleitores: " + (d.va+d.vb+d.vc+d.vbr+d.vn));
		System.out.print("Pecentual de votos Candidato A: " + ((d.va+d.vb+d.vc+d.vbr+d.vn)*d.va)/100 + "%" );
		System.out.print("Pecentual de votos Candidato B: " + ((d.va+d.vb+d.vc+d.vbr+d.vn)*d.vb)/100+ "%");
		System.out.print("Pecentual de votos Candidato C: "+ ((d.va+d.vb+d.vc+d.vbr+d.vn)*d.vc)/100+ "%");
		System.out.print("Pecentual de votos Brancos: " + ((d.va+d.vb+d.vc+d.vbr+d.vn)*d.vbr)/100+ "%");
		System.out.print("Pecentual de votos Nulos: " + ((d.va+d.vb+d.vc+d.vbr+d.vn)*d.vn)/100+ "%");
	}

}
