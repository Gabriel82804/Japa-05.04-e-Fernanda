import javax.swing.JOptionPane;

public class Treze_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Treze t = new Treze();
		t.n1 = Double.parseDouble(JOptionPane.showInputDialog("Digite um numero: "));
		t.n2 = Double.parseDouble(JOptionPane.showInputDialog("Digite um segundo numero: "));
		t.n3= Double.parseDouble(JOptionPane.showInputDialog("Digite um terceiro numero: "));
		
		if(t.n1 > t.n2 )\\(t.n1 > t.n3) {
			System.out.println("Crescente: " + t.n1 + t.n2 + t.n3 );
		}
		if(t.n1 > t.n3 > t.n2) {
			System.out.println("Crescente: " + t.n1 + t.n3 + t.n2 );
		}
		if(t.n2 > t.n1 > t.n3) {
			System.out.println("Crescente: " + t.n2 + t.n1 + t.n3 );
		}
		if(t.n2 > t.n3 > t.n1) {
			System.out.println("Crescente: " + t.n2 + t.n3 + t.n1 );
		}
		if(t.n3 > t.n2 > t.n1) {
			System.out.println("Crescente: " + t.n3 + t.n2 + t.n1 );
		}
		if(t.n3 > t.n1 > t.n2) {
			System.out.println("Crescente: " + t.n3 + t.n1 + t.n2 );
		}
	
	}

}
