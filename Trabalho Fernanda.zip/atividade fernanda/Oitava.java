import javax.swing.JOptionPane;

public class Oitava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Oit O = new Oit();
		O.n1 = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do boleto: "));
		O.n2 = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor de juros do boleto: "));
		O.n3 = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade de dias que venceu o boleto: "));
		
		System.out.print("Total a ser pago: " + O.n1 + (O.n1*O.n2/100)*O.n3);
	}

}
