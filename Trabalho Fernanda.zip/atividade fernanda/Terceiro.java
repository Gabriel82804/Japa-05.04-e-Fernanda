import javax.swing.JOptionPane;


public class Terceiro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Terc s1 = new Terc();
		s1.n1 = Integer .parseInt(JOptionPane .showInputDialog("Digite um numero para mult: "));
		s1.n2 = Integer .parseInt(JOptionPane .showInputDialog("Digite um numero para soma: "));
		s1.n3 = Integer .parseInt(JOptionPane .showInputDialog("Digite um segundo numero para mult: "));
		s1.n4 = Integer .parseInt(JOptionPane .showInputDialog("Digite um segundo numero para soma: "));
		
		System.out.println("Resposta Soma: " + (s1.n2 + s1.n4));
		System.out.println("Resposta Mult: " + (s1.n1 * s1.n3));
	}
}