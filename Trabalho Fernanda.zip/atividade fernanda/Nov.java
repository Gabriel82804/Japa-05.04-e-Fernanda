
public class Nov {

	double sal;
	double desp;
	
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public double getDesp() {
		return desp;
	}
	public void setDesp(double desp) {
		this.desp = desp;
	}
}
