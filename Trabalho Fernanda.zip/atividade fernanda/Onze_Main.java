import javax.swing.JOptionPane;

public class Onze_Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Onze o = new Onze();
		o.nome = JOptionPane.showInputDialog("Digite seu nome: ");
		o.id = Integer.parseInt(JOptionPane.showInputDialog("Digite sua idade: "));
		
		if(o.id<18) {
			System.out.print("Idade invalida");
		}if (o.id >= 18) {
			System.out.print("Sua idade:" + o.id);
		}
		
		
	}

}
