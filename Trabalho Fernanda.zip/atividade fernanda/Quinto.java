import javax.swing.JOptionPane;

public class Quinto {

	public static void main(String[] args) {
		
		Quin q = new Quin();
		q.n1 = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do pre�o do litro: "));
		q.n2 = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor que o cliente quer abastecer: "));
		
		System.out.print("Litros abastecidos: " + (q.n2/q.n1));

	}

}
