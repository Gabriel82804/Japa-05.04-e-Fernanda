import javax.swing.JOptionPane;

public class Test {

	public static void main(String[] args) {
		
			Cliente c = new Cliente();
			c.setNome(JOptionPane.showInputDialog("Digite o nome: "));
			c.setEmail(JOptionPane.showInputDialog("Digite o email: "));
			
			
			
			Endereco e = new Endereco();
			e.setLogradouro(JOptionPane.showInputDialog("Digite o logradouro: "));
			e.setNumero(JOptionPane.showInputDialog("Digite o Numero do local: "));
			e.setBairro(JOptionPane.showInputDialog("Digite o bairro: "));
			e.setCidade(JOptionPane.showInputDialog("Digite um Cidade: "));
			e.setUf(JOptionPane.showInputDialog("Digite o uf: "));
			e.setCep(JOptionPane.showInputDialog("Digite o CEP: ")); 
			
			c.setEndereco(e); 
			System.out.println("Logradouro: " + c.getEndereco().getLogradouro());
			System.out.println("Logradouro: " + c.getEndereco().getNumero());
			System.out.println("Logradouro: " + c.getEndereco().getBairro());
			System.out.println("Logradouro: " + c.getEndereco().getCidade());
			System.out.println("Logradouro: " + c.getEndereco().getUf());
			System.out.println("Logradouro: " + c.getEndereco().getCep());
			
			
			Telefone t = new Telefone();
			t.setDdd(JOptionPane.showInputDialog("Digite o ddd:"));
			t.setRamal(JOptionPane.showInputDialog("Digite o ramal:"));
			t.setNumero(JOptionPane.showInputDialog("Digite o numero: "));
			t.setOperadora(JOptionPane.showInputDialog("Digite a operadora: "));
			
			c.setTelefone(t);
			System.out.print("Numero: " + c.getTelefone().getNumero());
			System.out.print("Ramal: " + c.getTelefone().getRamal());
			System.out.print("Ramal: " + c.getTelefone().getDdd());
			System.out.print("Ramal: " + c.getTelefone().getOperadora());
		}
}
