
public class Cliente {

	private String nome;
	private String email;
	private Telefone Telefone;
	private Endereco endereco;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Telefone getTelefone() {
		return Telefone;
	}
	public void setTelefone(Telefone telefone) {
		Telefone = telefone;
	}
	public Endereco getEndereco() {
		return endereco;
	}
	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	public void setTelefone(String showInputDialog, Telefone Telefone) {
		this.Telefone = Telefone;
		
	}
	public void setEndereco(String showInputDialog, Endereco endereco) {
		this.endereco = endereco;
		
	}


}
