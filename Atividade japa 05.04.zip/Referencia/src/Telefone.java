
public class Telefone {

	private int numero;
	private int ramal;
	private String operadora;
	private short ddd;
	
	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getRamal() {
		return ramal;
	}

	public void setRamal(int ramal) {
		this.ramal = ramal;
	}

	public String getOperadora() {
		return operadora;
	}

	public void setOperadora(String operadora) {
		this.operadora = operadora;
	}

	public short getDdd() {
		return ddd;
	}

	public void setDdd(short ddd) {
		this.ddd = ddd;
	}

	public Telefone(int numero, int ramal, String operadora, short ddd) {
		super();
		this.numero = numero;
		this.ramal = ramal;
		this.operadora = operadora;
		this.ddd = ddd;
	}

	public Telefone() {
	}
	public void setDdd(String showInputDialog) {	
	}
	public void setRamal(String showInputDialog) {	
	}
	public void setNumero(String showInputDialog) {
	}
	
}
